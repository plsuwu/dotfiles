# Myra Mors Cursor Pack

Repackaged from the [Myra Mors Cursor Pack by FerenaiNexi](https://vgen.co/myramors/product/myra-mors-cursor-pack-by-frenainexi/a805640a-cb4f-4b02-8417-218816698e12)
on Vgen, repackaged with a simple script to convert from Windows' `.ani` cursor format to Linux `xcursor` format.

Primarily intended for my own use.

> Original 'HOW TO INSTALL.txt' contents:

```
Heyo! Thank you for downloading my cursor pack! It was made by @FerenaiNexi

To install on Windows, go to C:\Windows\Cursors and put the cursor files there.
Then, search for "change the mouse pointer display or speed", navigate to the "Pointers" tab, and then replace each
cursor with the new files. They are numbered by order to put in - but you can of course freely change which cursors you want to use
for what. At the top you can then "save as..." do save this cursor as a preset!

If the cursor is a little small, you can search for "change mouse pointer size" and adjust it there.

Let me know how you like your new cursor! Have fun!
```
